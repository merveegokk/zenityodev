#!/bin/bash

# Dosyaları başlat
initialize_files() {
    for file in depo.csv kullanici.csv log.csv; do
        if [[ ! -f $file ]]; then
            touch "$file"
            if [[ $? -eq 0 ]]; then
                echo "$file dosyası oluşturuldu."
            else
                zenity --error --text="Dosya oluşturulamadı: $file"
                exit 1
            fi
        fi
    done
}

# Şifreyi hash'le
hash_password() {
    echo -n "$1" | sha256sum | cut -d' ' -f1
}

# Kullanıcı Giriş Sistemi
login_system() {
    # Kullanıcı adı ve parola girişi
    kullanici_adi=$(zenity --entry --title="Giriş" --text="Kullanıcı adınızı girin:")
    parola=$(zenity --password --title="Giriş")
 
    # Kullanıcı doğrulama
    if grep -q "^$kullanici_adi," kullanici.csv; then
        # Kullanıcı bilgilerini oku
        kayit=$(grep "^$kullanici_adi," kullanici.csv)
        kaydedilen_parola=$(echo "$kayit" | cut -d',' -f2)
        rol=$(echo "$kayit" | cut -d',' -f3)

        # Parola doğrulama
        if [[ "$(hash_password "$parola")" == "$kaydedilen_parola" ]]; then
            zenity --info --text="Hoş geldiniz, $kullanici_adi!"
            if [[ "$rol" == "admin" ]]; then
                admin_menu
            else
                user_menu
            fi
        else
            zenity --error --text="Hatalı parola!"
            echo "$(date) - Kullanıcı $kullanici_adi hatalı parola girişi yaptı" >> log.csv
            exit 1
        fi
    else
        zenity --error --text="Kullanıcı bulunamadı!"
        echo "$(date) - Kullanıcı $kullanici_adi bulunamadı" >> log.csv
        exit 1
    fi
}

# Yönetici Menüsü
admin_menu() {
    choice=$(zenity --list --title="Yönetici Menüsü" --column="Seçim" \
    "Ürün Ekle" "Ürün Listele" "Ürün Güncelle" "Ürün Sil" "Kullanıcı Yönetimi" "Program Yönetimi" "Çıkış")
    
    case $choice in
        "Ürün Ekle") add_product ;;
        "Ürün Listele") list_products ;;
        "Ürün Güncelle") update_product ;;
        "Ürün Sil") delete_product ;;
        "Kullanıcı Yönetimi") user_management ;;
        "Program Yönetimi") program_management ;;
        "Çıkış") exit 0 ;;
    esac
}

# Kullanıcı Menüsü
user_menu() {
    choice=$(zenity --list --title="Kullanıcı Menüsü" --column="Seçim" \
    "Ürün Listele" "Rapor Al" "Çıkış")
    
    case $choice in
        "Ürün Listele") list_products ;;
        "Rapor Al") generate_report ;;
        "Çıkış") exit 0 ;;
    esac
}

# Ürün Ekle
add_product() {
    product_name=$(zenity --entry --title="Ürün Ekle" --text="Ürün Adını Girin:")
    stock=$(zenity --entry --title="Ürün Ekle" --text="Stok Miktarını Girin:")
    price=$(zenity --entry --title="Ürün Ekle" --text="Birim Fiyatını Girin:")
    category=$(zenity --entry --title="Ürün Ekle" --text="Kategori Girin:")

    if [[ -z "$product_name" || -z "$stock" || -z "$price" || -z "$category" ]]; then
        zenity --error --text="Tüm alanlar doldurulmalıdır!"
        return
    fi

    if ! [[ "$stock" =~ ^[0-9]+$ ]] || ! [[ "$price" =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
        zenity --error --text="Stok ve fiyat sayısal olmalıdır!"
        return
    fi

    # Ürün ekleme ve dosyaya yazma
    last_product_id=$(tail -n 1 depo.csv | cut -d',' -f1)
    new_product_id=$((last_product_id + 1))
    echo "$new_product_id,$product_name,$stock,$price,$category" >> depo.csv
    zenity --info --text="Ürün başarıyla eklendi."
}

# Ürün Listele
list_products() {
    products=$(cat depo.csv | while IFS=',' read -r id name stock price category; do
        echo "ID: $id, Ad: $name, Stok: $stock, Fiyat: $price, Kategori: $category"
    done)
    echo "$products"
    zenity --text-info --title="Ürün Listeleme" --text="$products"
}

# Ürün Güncelle
update_product() {
    product_name=$(zenity --entry --title="Ürün Güncelle" --text="Güncellemek istediğiniz ürünün adını girin:")
    product_id=$(grep -m 1 "^.*,$product_name" depo.csv | cut -d',' -f1)
    
    if [[ -z "$product_id" ]]; then
        zenity --error --text="Ürün bulunamadı!"
        return
    fi

    new_stock=$(zenity --entry --title="Ürün Güncelle" --text="Yeni stok miktarını girin:")
    new_price=$(zenity --entry --title="Ürün Güncelle" --text="Yeni birim fiyatını girin:")

    # Stok ve fiyat doğrulama
    if ! [[ "$new_stock" =~ ^[0-9]+$ ]] || ! [[ "$new_price" =~ ^[0-9]+(\.[0-9]+)?$ ]]; then
        zenity --error --text="Geçersiz giriş! Stok ve fiyat sayısal olmalıdır."
        return
    fi

    # Ürün güncelleme
    sed -i "/^$product_id,/s/\($product_id,[^,],[^,],[^,],[^,]\)/\1$new_stock,$new_price/" depo.csv
    zenity --info --text="Ürün başarıyla güncellendi."
}

# Ürün Sil
delete_product() {
    product_name=$(zenity --entry --title="Ürün Sil" --text="Silmek istediğiniz ürünün adını girin:")
    product_id=$(grep -m 1 "^.*,$product_name" depo.csv | cut -d',' -f1)

    if [[ -z "$product_id" ]]; then
        zenity --error --text="Ürün bulunamadı!"
        return
    fi

    # Ürün silme
    sed -i "/^$product_id,/d" depo.csv
    zenity --info --text="Ürün başarıyla silindi."
}

# Kullanıcı Yönetimi
user_management() {
    choice=$(zenity --list --title="Kullanıcı Yönetimi" --column="Seçim" \
    "Yeni Kullanıcı Ekle" "Kullanıcıları Listele" "Kullanıcı Güncelle" "Kullanıcı Sil" "Geri")

    case $choice in
        "Yeni Kullanıcı Ekle") add_user ;;
        "Kullanıcıları Listele") list_users ;;
        "Kullanıcı Güncelle") update_user ;;
        "Kullanıcı Sil") delete_user ;;
        "Geri") admin_menu ;;
    esac
}

# Kullanıcı Ekle
add_user() {
    user_name=$(zenity --entry --title="Yeni Kullanıcı Ekle" --text="Kullanıcı Adı Girin:")
    password=$(zenity --entry --title="Yeni Kullanıcı Ekle" --text="Parola Girin:" --hide-text)
    role=$(zenity --list --title="Yeni Kullanıcı Ekle" --column="Rol" "admin" "user")

    if [[ -z "$user_name" || -z "$password" || -z "$role" ]]; then
        zenity --error --text="Tüm alanlar doldurulmalıdır!"
        return
    fi

    # Kullanıcı adı benzersizliğini kontrol et
    if grep -q "^$user_name," kullanici.csv; then
        zenity --error --text="Bu kullanıcı adı zaten mevcut!"
        return
    fi

    # Kullanıcıyı ekle
    hashed_password=$(hash_password "$password")
    echo "$user_name,$hashed_password,$role" >> kullanici.csv
    zenity --info --text="Kullanıcı başarıyla eklendi."
}

# Kullanıcı Listele
list_users() {
    users=$(cat kullanici.csv | while IFS=',' read -r username password role; do
        echo "Kullanıcı Adı: $username, Rol: $role"
    done)
    
    zenity --text-info --title="Kullanıcı Listeleme" --text="$users"
}

# Kullanıcı Güncelle
update_user() {
    user_name=$(zenity --entry --title="Kullanıcı Güncelle" --text="Güncellemek istediğiniz kullanıcı adını girin:")
    user_record=$(grep "^$user_name," kullanici.csv)
    
    if [[ -z "$user_record" ]]; then
        zenity --error --text="Kullanıcı bulunamadı!"
        return
    fi

    new_password=$(zenity --entry --title="Kullanıcı Güncelle" --text="Yeni parolayı girin:" --hide-text)
    new_role=$(zenity --list --title="Kullanıcı Güncelle" --column="Rol" "admin" "user")

   # Kullanıcıyı güncelle
    hashed_password=$(hash_password "$new_password")
    sed -i "/^$user_name,/s/\($user_name,[^,],[^,]\)/\1$hashed_password,$new_role/" kullanici.csv
    zenity --info --text="Kullanıcı başarıyla güncellendi."
}

# Kullanıcı Sil
delete_user() {
    user_name=$(zenity --entry --title="Kullanıcı Sil" --text="Silmek istediğiniz kullanıcı adını girin:")
    user_record=$(grep "^$user_name," kullanici.csv)

    if [[ -z "$user_record" ]]; then
        zenity --error --text="Kullanıcı bulunamadı!"
        return
    fi

    # Kullanıcıyı sil
    sed -i "/^$user_name,/d" kullanici.csv
    zenity --info --text="Kullanıcı başarıyla silindi."
}

# Program Yönetimi
program_management() {
    zenity --info --text="Program yönetimi işlemleri yapılacak."
    admin_menu
}

# Ana Betik
main() {
    initialize_files

    # Varsayılan bir yönetici hesabı ekle (eğer yoksa)
    if ! grep -q "^admin," kullanici.csv; then
        hashed_password=$(hash_password "admin123")
        echo "admin,$hashed_password,admin" >> kullanici.csv
        echo "Yönetici hesabı eklendi: admin / admin123"
    fi

    login_system
}

main
